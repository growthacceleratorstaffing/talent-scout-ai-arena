import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Job ads table
export const jobAds = pgTable("job_ads", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements").notNull(),
  location: text("location"),
  salary: text("salary"),
  company: text("company").notNull(),
  status: text("status").default("active"), // active, inactive, filled
  createdAt: timestamp("created_at").defaultNow(),
  userId: integer("user_id").references(() => users.id),
});

// Candidates table
export const candidates = pgTable("candidates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  resumeUrl: text("resume_url"),
  skills: text("skills").array(),
  experience: text("experience"),
  currentPosition: text("current_position"),
  location: text("location"),
  score: integer("score"),
  evaluationData: jsonb("evaluation_data"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Applications table
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  candidateId: integer("candidate_id").references(() => candidates.id),
  jobAdId: integer("job_ad_id").references(() => jobAds.id),
  status: text("status").default("pending"), // pending, reviewed, accepted, rejected
  score: integer("score"),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  fullName: true,
});

export const insertJobAdSchema = createInsertSchema(jobAds).pick({
  title: true,
  description: true,
  requirements: true,
  location: true,
  salary: true,
  company: true,
});

export const insertCandidateSchema = createInsertSchema(candidates).pick({
  name: true,
  email: true,
  phone: true,
  resumeUrl: true,
  skills: true,
  experience: true,
  currentPosition: true,
  location: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertJobAd = z.infer<typeof insertJobAdSchema>;
export type JobAd = typeof jobAds.$inferSelect;
export type InsertCandidate = z.infer<typeof insertCandidateSchema>;
export type Candidate = typeof candidates.$inferSelect;
export type Application = typeof applications.$inferSelect;
