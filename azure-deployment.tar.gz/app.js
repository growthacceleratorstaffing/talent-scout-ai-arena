// Simple Azure App Service entry point
const express = require('express');
const path = require('path');

const app = express();

// Set environment
process.env.NODE_ENV = 'production';

// Serve static files from dist/public (built React app)
app.use(express.static(path.join(__dirname, 'dist/public')));

// Basic API health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    port: process.env.PORT || 'not-set'
  });
});

// Fallback for React Router (serve index.html for all non-API routes)
app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) {
    res.status(404).json({ error: 'API endpoint not found' });
  } else {
    res.sendFile(path.join(__dirname, 'dist/public/index.html'));
  }
});

// Get port from environment or default to 8080 (Azure default)
const port = process.env.PORT || 8080;

app.listen(port, '0.0.0.0', () => {
  console.log(`Azure App Service running on port ${port}`);
  console.log(`Environment: ${process.env.NODE_ENV}`);
  console.log(`Static files served from: ${path.join(__dirname, 'dist/public')}`);
});