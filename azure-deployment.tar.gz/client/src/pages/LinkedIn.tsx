
import React from 'react';
import Navigation from '@/components/Navigation';
import LinkedInDashboard from '@/components/LinkedInDashboard';

const LinkedIn = () => {
  return (
    <>
      <Navigation />
      <div className="container mx-auto py-6">
        <LinkedInDashboard />
      </div>
    </>
  );
};

export default LinkedIn;
