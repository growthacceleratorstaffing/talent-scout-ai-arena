import React from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Users, UserX, Briefcase, Bot, ClipboardCheck, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useServerAuth";

const Navigation = () => {
  const [location] = useLocation();
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
  };
  
  const navItems = [
    { path: '/', label: 'Dashboard', icon: Briefcase },
    { path: '/ads', label: 'Job Ads', icon: Sparkles },
    { path: '/applicants', label: 'Applicants', icon: Users },
    { path: '/ai-interview', label: 'AI Interview', icon: Bot },
    { path: '/assessment', label: 'Assessment', icon: ClipboardCheck },
    { path: '/talent-pool', label: 'Talent Pool', icon: UserX },
    { path: '/matching', label: 'Matching', icon: Users }
  ];

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 w-full">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">GA</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Growth Accelerator</span>
            </div>
            
            <div className="flex items-center space-x-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.path;
                
                return (
                  <Link key={item.path} to={item.path}>
                    <Button
                      variant={isActive ? "default" : "ghost"}
                      size="sm"
                      className={`flex items-center gap-2 ${
                        isActive 
                          ? "bg-blue-600 text-white hover:bg-blue-700" 
                          : "text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </div>
          </div>

          <div className="flex items-center">
            <Button variant="outline" size="sm" onClick={handleSignOut} className="flex items-center gap-2">
              <LogOut className="h-4 w-4" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
