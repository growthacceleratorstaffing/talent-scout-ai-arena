
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router, Route } from "wouter";
import { AuthProvider } from "@/hooks/useServerAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Ads from "./pages/Ads";
import TalentPool from "./pages/TalentPool";
import Matching from "./pages/Matching";
import Applicants from "./pages/Applicants";
import LinkedIn from "./pages/LinkedIn";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";
import FloatingAIAgent from "@/components/ai/FloatingAIAgent";
import SuperAIAgent from "@/components/ai/SuperAIAgent";
import AiInterview from "./pages/AiInterview";
import Assessment from "./pages/Assessment";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Router>
          <FloatingAIAgent />
          <SuperAIAgent />
          <Route path="/auth" component={Auth} />
          <Route path="/">
            <ProtectedRoute>
              <Index />
            </ProtectedRoute>
          </Route>
          <Route path="/ads">
            <ProtectedRoute>
              <Ads />
            </ProtectedRoute>
          </Route>
          <Route path="/applicants">
            <ProtectedRoute>
              <Applicants />
            </ProtectedRoute>
          </Route>
          <Route path="/talent-pool">
            <ProtectedRoute>
              <TalentPool />
            </ProtectedRoute>
          </Route>
          <Route path="/matching">
            <ProtectedRoute>
              <Matching />
            </ProtectedRoute>
          </Route>
          <Route path="/ai-interview">
            <ProtectedRoute>
              <AiInterview />
            </ProtectedRoute>
          </Route>
          <Route path="/assessment">
            <ProtectedRoute>
              <Assessment />
            </ProtectedRoute>
          </Route>
          <Route path="/linkedin">
            <ProtectedRoute>
              <LinkedIn />
            </ProtectedRoute>
          </Route>
          <Route component={NotFound} />
        </Router>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
